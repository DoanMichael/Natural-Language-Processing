import sys
import numpy as np
from scipy.special import softmax
from collections import Counter

"""
Your name and file comment here: Michael Doan
"""

"""
Cite your sources here: https://nlpforhackers.io/named-entity-extraction/
"""

def generate_tuples_from_file(file_path):
    current = []
    f = open(file_path, "r", encoding="utf8")
    examples = []
    for line in f:
        if len(line.strip()) == 0 and len(current) > 0:
            examples.append(current)
            current = []
        else:
            pieces = line.strip().split()
            current.append(tuple(pieces[1:]))
    if len(current) > 0:
        examples.append(current)
    f.close()
    return examples

def get_words_from_tuples(examples):
    return [[t[0] for t in example] for example in examples]

def decode(data, probability_table, pointer_table):
    start = max(probability_table[-1].items(), key=lambda x: x[1])[0]
    result = [None for i in range(len(probability_table) - 1)]
    result += [(data[-1], start)]

    for index in reversed(range(len(pointer_table) - 1)):
        last_token = result[index + 1][1]
        result[index] = (data[index], pointer_table[index + 1][last_token])

    return result

def precision(gold_labels, classified_labels):
    gold = [x[1] for x in gold_labels]
    classif = [x[1] for x in classified_labels]
    tp, fp = get_tp_fp(gold, classif)

    if tp + fp == 0:
        return 0
    
    return tp / (tp + fp)

def recall(gold_labels, classified_labels):
  gold = [x[1] for x in gold_labels]
  classif = [x[1] for x in classified_labels]
  tp, fn = get_tp_fp(classif, gold)

  if tp + fn == 0:
      return 0

  return tp / (tp + fn)

def f1(gold_labels, classified_labels):
    recall_val = recall(gold_labels, classified_labels)
    precision_val = precision(gold_labels, classified_labels)

    if precision_val + recall_val == 0:
        return 0

    result = 2 * precision_val * recall_val
    result /= (precision_val + recall_val)

    return result

def pretty_print_table(data, list_of_dicts):
    keys = None

    for d in list_of_dicts:
        if keys is None:
            keys = d.keys()
        else:
            if d.keys() != keys:
                print("Error! not all dicts have the same keys!")
                return

    header = "\t" + "\t".join(['{:11.10s}'] * len(data))
    header = header.format(*data)
    rows = []

    for k in keys:
        r = k + "\t"

        for d in list_of_dicts:

            if type(d[k]) is float:
                r += '{:.9f}'.format(d[k]) + "\t"

            else:
                r += '{:10.9s}'.format(str(d[k])) + "\t"
        
        rows.append(r)
    
    print(header)

    for row in rows:
        print(row)

"""
Implement any other non-required functions here
"""

def get_tp_fp(gold, classified):
    tp = 0
    fp = 0
    index = 0

    while index < len(gold):
        
        if classified[index] == 'B':
            correct = True

            while index < len(gold) and classified[index] != 'O':

                if classified[index] != gold[index]:
                  correct = False
                  break
                index += 1

            if correct and classified[index] != gold[index]:
              correct = False

            if correct:
                tp += 1

            else:
                fp += 1

        index += 1

    return tp, fp

"""
Implement the following class
"""

class NamedEntityRecognitionHMM:
    def __init__(self):
        self.tags = ['I', 'O', 'B']
        self.pi_values = {t: 0 for t in self.tags}
        self.vocab = []
        self.transitions = {}
        self.emissions = {}

    def train(self, examples, verbose=False):
        self.__init__()

        for sentence in examples:
            tag = sentence[0][1]
            self.pi_values[tag] += 1 / len(examples)
            prev_tag = None
            
            for word, tag in sentence:
                
                if word not in self.vocab:
                    self.vocab.append(word)

                if prev_tag:

                    if prev_tag not in self.transitions:
                        self.transitions[prev_tag] = Counter()
                    self.transitions[prev_tag][tag] += 1

                if tag not in self.emissions:
                    self.emissions[tag] = Counter()

                self.emissions[tag][word] += 1
                prev_tag = tag

    def generate_probabilities(self, data):
        def calculate_prob(coef, tag, token):
            return coef * (self.emissions[tag][token] + 1) / (sum(self.emissions[tag].values()) + len(self.vocab))

        def calculate_tag_val(sub, tag, prev_prob):
            return (self.transitions[sub][tag] / sum(self.emissions[sub].values())) * prev_prob

        res_probs = [{x: calculate_prob(self.pi_values[x], x, data[0]) for x in self.tags}]
        res_pointers = [{x: None for x in self.tags}]

        for i in range(1, len(data)):
            probs = {}
            pointers = {}

            for tag in self.tags:
                need_gen = ((calculate_tag_val(s, tag, res_probs[i-1][s]), s) for s in self.tags)
                top_value, top_key = max(need_gen, key=lambda x: x[0])

                pointers[tag] = top_key
                probs[tag] = calculate_prob(top_value, tag, data[i])

            res_probs.append(probs)
            res_pointers.append(pointers)

        return res_probs, res_pointers

    def __str__(self):
        return "HMM"

"""
Implement the following class
"""

class NamedEntityRecognitionMEMM:
    def __init__(self):
        import string
        self.tags = ['I', 'O', 'B']
        self.feature_rules = {
            'Starts with upper': lambda x: x[0].isupper(),
            'Contains digits': lambda x: any(char.isdigit() for char in x),
            'Contains punctuation': lambda x: any(comma in x for comma in string.punctuation),
            'Length of element': lambda x: len(x),
            'Ending on -ing': lambda x: x.endswith('ing'),
            'Ending on -ed': lambda x: x.endswith('ed'),
            'Ending on -ment': lambda x: x.endswith('ment'),
            'Ending on -ness': lambda x: x.endswith('ness'),
            'Ending on -ly': lambda x: x.endswith('ly'),
            'Ending on -log': lambda x: x.endswith('log'),
            'Ending on -aholic': lambda x: x.endswith('aholic'),
            'Ending on -cracy': lambda x: x.endswith('cracy'),
            'Ending on -ern': lambda x: x.endswith('ern'),
            'Ending on -ful': lambda x: x.endswith('ful')
        }

        self.n_before = 2
        self.n_after = 2
        self.weights = np.random.rand(len(self.feature_rules) * (self.n_before + self.n_after), len(self.tags))
        self.b = np.zeros(len(self.tags))

    def train(self, examples, iterations=100, learning_rate=0.01, verbose=False):
        import random

        for _ in range(iterations):
            glob_loss = 0
            for sentence in random.sample(examples, len(examples)):
                target = np.array([[1 if self.tags.index(x[1]) == i else 0 for i in range(len(self.tags))] for x in sentence])
                words = [x[0] for x in sentence]
                featurized = self.featurize(words)
                predict_proba = softmax(featurized @ self.weights + self.b, axis=1)
                loss = -(target * np.log(predict_proba)).sum(axis=1).mean()
                glob_loss += loss
                dy = target - predict_proba
                self.weights += learning_rate * featurized.T@dy
                self.b += learning_rate * dy.mean(axis=0)

            if verbose:
                print(f"{_} Iteration: Loss: {glob_loss/len(examples)}")

    def featurize(self, sentence):
        n_feat = len(self.feature_rules)
        features = np.zeros((len(sentence), n_feat*(self.n_after + self.n_before)))

        for i, word in enumerate(sentence):
            to_put = np.zeros(features.shape[1])

            for b_i in range(self.n_before):

                if i - b_i > -1:
                    to_put[b_i * n_feat : (b_i + 1) * n_feat] = np.array([func(sentence[i - b_i])for _, func in self.feature_rules.items()])

            for a_i in range(self.n_before):

                if i + a_i < len(sentence):
                    to_put[a_i * n_feat : (a_i + 1) * n_feat] = np.array([func(sentence[i + a_i])for _, func in self.feature_rules.items()])

            to_put[self.n_before * n_feat : (self.n_before + 1) * n_feat] = np.array([func(word)for _, func in self.feature_rules.items()])
            features[i, :] = to_put

        return features

    def generate_probabilities(self, data):
        featurized = self.featurize(data)

        def calculate_prob(vector):
            vector = vector.reshape(1, -1)
            return softmax(vector @ self.weights + self.b, axis=1).flatten()

        predictions = [calculate_prob(featurized[0:1,:])]
        res_probs = [{x: y for x, y in zip(self.tags, list(predictions[0].flatten()))}]
        res_pointers = [{x: None for x in self.tags}]

        for i in range(1, len(featurized)):
            prediction = calculate_prob(featurized[i, :])
            pointers = {}
            probs = {}

            for index, tag in enumerate(self.tags):
                need_gen = [((prediction[index]*predictions[i-1][i_s]), s) for i_s, s in enumerate(self.tags)]
                top_value, top_key = max(need_gen, key=lambda x: x[0])
                pointers[tag] = top_key
                probs[tag] = prediction[index] * top_value

            predictions.append(prediction)
            res_probs.append(probs)
            res_pointers.append(pointers)

        return res_probs, res_pointers

    def __str__(self):
        return "MEMM"

if __name__ == "__main__":

    if len(sys.argv) != 3:
        print("Usage:", "python hw5_ner.py training-file.txt testing-file.txt")
        sys.exit(1)

    training = sys.argv[1]
    testing = sys.argv[2]
    training_examples = generate_tuples_from_file(training)
    testing_examples = generate_tuples_from_file(testing)
    training_examples = training_examples[0:1000]
    models = [NamedEntityRecognitionMEMM]
    test_sentences = [[y[0] for y in x] for x in testing_examples]
    flat_test_examples = [item for sublist in testing_examples for item in sublist]
    metrics = {
        'precision': lambda x, y: precision(x, y),
        'recall': lambda x, y: recall(x, y),
        'f1_score': lambda x, y: f1(x, y)
    }

    for model in models:
        model.train(training_examples, learning_rate=0.01, iterations=100,verbose=True)
        output = [decode(sent, *model.generate_probabilities(sent)) for sent in test_sentences]
        print(f"Model: {str(model)}")

        for m_name, func in metrics.items():
            values = [func(g, cl) for g, cl in zip(testing_examples, output)]
            print(f"Mean {m_name} over test examples: {np.median(values)}")
            flat_output = [item for sublist in output for item in sublist]
            print(f"Generalized {m_name} on flattened samples: {func(flat_test_examples, flat_output)}")