# STEP 1: rename this file to hw3_sentiment.py

# feel free to include more imports as needed here
# these are the ones that we used for the base model
import numpy as np
import sys
from collections import Counter
import math

"""
Your name and file comment here: Michael Doan
"""


"""
Cite your sources here: https://towardsdatascience.com/introduction-to-na%C3%AFve-bayes-classifier-fa59e3e24aaf?fbclid=IwAR3MHEgQVSUWUIZq9jZu6V1tZnvNPGEan2xihh1agC5KKsJyDZQwTJoUwyI
"""

"""
Implement your functions that are not methods of the Sentiment Analysis class here
"""
def generate_tuples_from_file(training_file_path):
    result = []
    with open(training_file_path, "r") as f:
        for row in f:
            result.append(tuple(x.strip() for x in row.split('\t')))
    return [x for x in result if len(x) > 1]


def precision(gold_labels, classified_labels):
    iterate = range(len(gold_labels))

    tp = sum(gold_labels[i]==classified_labels[i] and gold_labels[i] == '1' for i in iterate)
    fp = sum(gold_labels[i]!=classified_labels[i] and classified_labels[i] == '1' for i in iterate)
    return tp/(tp+fp)


def recall(gold_labels, classified_labels):
    iterate = range(len(gold_labels))
    tp = sum(gold_labels[i]==classified_labels[i] and gold_labels[i] == '1' for i in iterate)
    fn = sum(gold_labels[i]!=classified_labels[i] and classified_labels[i] == '0' for i in iterate)
    return tp/(tp+fn)

def f1(gold_labels, classified_labels):
    pr = precision(gold_labels, classified_labels)
    rec = recall(gold_labels, classified_labels)
    return (2*pr*rec)/(pr + rec)

"""
Implement any other non-required functions here
"""



"""
implement your SentimentAnalysis class here
"""
class SentimentAnalysis:
    def __init__(self):
        self.vocab = set()
        self.vocab_1 = {}
        self.vocab_0 = {}
        self.prior_counts = {0:0, 1:0}
        self.log_class_priors = {}

    def train(self, examples):
        import numpy as np

        for _, data, label in examples:
            words = self.featurize(data)

            self.prior_counts[int(label)] += 1

            dict_to_work = self.vocab_0

            if label == '1':
                dict_to_work = self.vocab_1

            for word, count in words:
                dict_to_work[word] = dict_to_work.get(word, 0) + int(count)
                self.vocab.add(word)

        n = self.prior_counts[0] + self.prior_counts[1]
        self.log_class_priors[0] = np.log(self.prior_counts[0] / n)
        self.log_class_priors[1] = np.log(self.prior_counts[1] / n)


    def score(self, data):
        import numpy as np

        counts = self.featurize(data)

        score_1 = score_0 = 0

        for word, _ in counts:
            if word not in self.vocab:
                continue

            score_1 += np.log((self.vocab_1.get(word, 0) + 1) / (sum(x for _, x in self.vocab_1.items()) + len(self.vocab)))
            score_0 += np.log( (self.vocab_0.get(word, 0) + 1) / (sum(x for _, x in self.vocab_0.items())+ len(self.vocab)))


        score_1 += self.log_class_priors[1]
        score_0 += self.log_class_priors[0]

        return {
            '0': np.exp(score_0),
            '1': np.exp(score_1)
        }


    def classify(self, data):
        scores = self.score(data)
        if scores['0'] >= scores['1']:
            return '0'
        return '1'

    def featurize(self, data):
        import string
        import re

        #translator = str.maketrans("", "", string.punctuation)
        #text = data.translate(translator)
        #words = re.split("\W+", data)
        return [(x, True) for x in data.split()]


    def __str__(self):
        return "Naive Bayes - bag-of-words baseline"


class SentimentAnalysisImproved:
    def __init__(self):
        self.stopwords = ["i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", "yours", "yourself", "yourselves", "he", "him", "his", "himself", "she", "her", "hers", "herself", "it", "its", "itself", "they", "them", "their", "theirs", "themselves", "what", "which", "who", "whom", "this", "that", "these", "those", "am", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "having", "do", "does", "did", "doing", "a", "an", "the", "and", "but", "if", "or", "because", "as", "until", "while", "of", "at", "by", "for", "with", "about", "against", "between", "into", "through", "during", "before", "after", "above", "below", "to", "from", "up", "down", "in", "out", "on", "off", "over", "under", "again", "further", "then", "once", "here", "there", "when", "where", "why", "how", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such", "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very", "s", "t", "can", "will", "just", "don", "should", "now"]
        self.vocab = set()
        self.vocab_1 = {}
        self.vocab_0 = {}
        self.prior_counts = {0:0, 1:0}
        self.log_class_priors = {}

    def train(self, examples):
        import numpy as np

        for _, data, label in examples:
            words = self.featurize(data)
            self.prior_counts[int(label)] += 1

            dict_to_work = self.vocab_0

            if label == '1':
                dict_to_work = self.vocab_1

            for word, count in words.items():
                if word in self.stopwords:
                    continue

                dict_to_work[word] = dict_to_work.get(word, 0) + count
                self.vocab.add(word)

        n = self.prior_counts[0] + self.prior_counts[1]
        self.log_class_priors[0] = np.log(self.prior_counts[0] / n)
        self.log_class_priors[1] = np.log(self.prior_counts[1] / n)


    def score(self, data):
        import numpy as np

        counts = self.featurize(data)

        score_1 = score_0 = 0

        for word, _ in counts.items():
            if word not in self.vocab:
                continue
            score_1 += np.log((self.vocab_1.get(word, 0) + 1) / (sum(x for _, x in self.vocab_1.items()) + len(self.vocab)))
            score_0 += np.log((self.vocab_0.get(word, 0) + 1) / (sum(x for _, x in self.vocab_0.items())+ len(self.vocab)))



        score_1 += self.log_class_priors[1]
        score_0 += self.log_class_priors[0]

        return {
            '0': np.exp(score_0),
            '1': np.exp(score_1)
        }


    def classify(self, data):
        scores = self.score(data)
        if scores['0'] >= scores['1']:
            return '0'
        return '1'

    def featurize(self, data):
        import string
        import re
        from collections import Counter

        translator = str.maketrans("", "", string.punctuation)
        text = data.translate(translator)
        text = text.lower()
        words = re.split("\W+", text)
        return dict(Counter(words))


    def __str__(self):
        return "Improved Bayes"


if __name__ == "__main__":
  if len(sys.argv) != 3:
    print("Usage:", "python hw3_sentiment.py training-file.txt testing-file.txt")
    sys.exit(1)

  training = sys.argv[1]
  testing = sys.argv[2]

  sa = SentimentAnalysis()
  print(sa)
  # do the things that you need to with your base class
  sa.train(generate_tuples_from_file(training))
  test_data = generate_tuples_from_file(testing)

  gold = [x[2] for x in test_data]
  predicted = [sa.classify(x[1]) for x in test_data]

  print(f"Precision: {precision(gold, predicted)}")
  print(f"Recall: {recall(gold, predicted)}")
  print(f"F1: {f1(gold, predicted)}")

  improved = SentimentAnalysisImproved()
  print(improved)
  # do the things that you need to with your improved class
  improved.train(generate_tuples_from_file(training))
  test_data = generate_tuples_from_file(testing)

  gold = [x[2] for x in test_data]
  predicted = [improved.classify(x[1]) for x in test_data]

  print(f"Precision: {precision(gold, predicted)}")
  print(f"Recall: {recall(gold, predicted)}")
  print(f"F1: {f1(gold, predicted)}")
